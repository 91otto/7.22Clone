class HttpConfig {
  static const String baseURL = "http://123.207.32.32:8001/api";
  static const int timeout = 10000;
}