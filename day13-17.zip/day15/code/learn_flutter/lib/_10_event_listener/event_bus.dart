import 'package:event_bus/event_bus.dart';

final eventBus = EventBus();