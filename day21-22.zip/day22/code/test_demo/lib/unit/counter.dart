class Counter {
  int value = 0;

  int increment() => value++;
  int decrement() => value--;
}
