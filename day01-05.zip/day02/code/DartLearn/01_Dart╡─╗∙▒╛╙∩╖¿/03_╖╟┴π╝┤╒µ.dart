main(List<String> args) {
  var flag = "abc";

  if (flag) {
    print("执行代码");
  }
}